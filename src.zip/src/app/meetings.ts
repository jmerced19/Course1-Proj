export class Meeting {
    constructor
    (topic: string,
        numberOfPeople: number,
        startTime: string) {
    }
}